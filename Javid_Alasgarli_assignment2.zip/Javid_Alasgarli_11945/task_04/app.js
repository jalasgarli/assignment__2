let gl, program;
let vertexCount = 36; // Number of vertices in the cube
let modelViewMatrix;
let projectionMatrix;
let pmode = 'perspective';

let vBuffer;
let vBuffer2;
let vPosition;

let distancaE = 7.3;
let eye = [0, 0, -distancaE]; // Initial camera position
let at = [0, 0, 0]; // Camera target
let up = [0, 1, 0]; // Up vector for the camera

// Orthographic projection parameters
let left = -distancaE;
let right = distancaE;
let bottom = -distancaE;
let ytop = distancaE;
let near = 0.001;
let far = 100

let fovy = 60; // Field of view angle in degrees
let theta = 0.1; // Rotation angle in radians

let camera_sensitivity = 0.08;
let cmode = 'F';

onload = () => {
    let canvas = document.getElementById("webgl-canvas");

    gl = WebGLUtils.setupWebGL(canvas);
    if (!gl) {
        alert('No webgl for you');
        return;
    }

    program = initShaders(gl, 'vertex-shader', 'fragment-shader');
    gl.useProgram(program);

    gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);

    gl.enable(gl.DEPTH_TEST);

    gl.clearColor(0, 0, 0, 0.5);

    let vertices = [
        -1, -1, 1, 
        -1, 1, 1,
        1, 1, 1,
        1, -1, 1, 
        -1, -1, -1, 
        -1, 1, -1,
        1, 1, -1,
        1, -1, -1,
    ];

    let vertices2 = [
        3, -1, -1,
        3, 1, -1,
        5, 1, -1,
        5, -1, -1,
        3, -1, -3,
        3, 1, -3,
        5, 1, -3,
        5, -1, -3,
    ];

    let indices = [
        0, 3, 1,
        1, 3, 2,
        4, 7, 5,
        5, 7, 6,
        3, 7, 2,
        2, 7, 6,
        4, 0, 5,
        5, 0, 1,
        1, 2, 5,
        5, 2, 6,
        0, 3, 4,
        4, 3, 7,
    ];

    let colors = [
        0, 0, 0,
        0, 0, 1,
        0, 1, 0,
        0, 1, 1,
        1, 0, 0,
        1, 0, 1,
        1, 1, 0,
        1, 1, 1,
    ];

    vBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);

    vBuffer2 = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer2);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices2), gl.STATIC_DRAW);

    vPosition = gl.getAttribLocation(program, 'vPosition');
    gl.vertexAttribPointer(vPosition, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);

    // Create index buffer
    let iBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, iBuffer);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint8Array(indices), gl.STATIC_DRAW);

    // Create color buffer
    let cBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, cBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(colors), gl.STATIC_DRAW);

    // Set the vertex color attribute
    let vColor = gl.getAttribLocation(program, 'vColor');
    gl.vertexAttribPointer(vColor, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vColor);

    modelViewMatrix = gl.getUniformLocation(program, 'modelViewMatrix');
    projectionMatrix = gl.getUniformLocation(program, 'projectionMatrix');

    // adding eventlistener in order to handle camera controls
    document.addEventListener('keydown', handleKeyDown);

    // rendering loop
    render();
};


function render() {
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    let aspect = 1;

    switch(pmode) {
        case "ortho":
            projectionMatrixValue = ortho(left, right, bottom, ytop, near, far);
            break;
        case "perspective":
            projectionMatrixValue = perspective(fovy, aspect, near, far);
            break;
    }

    mvm = lookAt(eye, at, up);

    gl.uniformMatrix4fv(modelViewMatrix, false,flatten(mvm));
    gl.uniformMatrix4fv(projectionMatrix, false,flatten(projectionMatrixValue));

    // drawing first cube
    gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer);
    gl.vertexAttribPointer(vPosition, 3, gl.FLOAT, false, 0, 0);
    gl.drawElements(gl.TRIANGLES, vertexCount, gl.UNSIGNED_BYTE, 0);

    //drawing second cube
    gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer2);
    gl.vertexAttribPointer(vPosition, 3, gl.FLOAT, false, 0, 0);
    gl.drawElements(gl.TRIANGLES, vertexCount, gl.UNSIGNED_BYTE, 0);
}

function handleKeyDown(event) {
    switch (event.key) {
        case 'T': // Top-side view
            cmode = 'T';
            eye = [0.0, distancaE, 0.01];
            at = [0.0, 0.0, 0.0];
            break;
            break;
        case 'L': // Left-side view
            cmode = 'L';
            eye = [distancaE, 0.0, 0.01];
            at = [0.0, 0.0, 0.0];
            break;
        case 'F': // Front-side view
            cmode = 'R';
            eye = [0, 0, distancaE];
            at = [0.0, 0.0, 0.0];
            break;
        case 'D': // Rotate camera clockwise
            theta += camera_sensitivity;
            up = vec3(
                Math.cos(theta + Math.PI / 2), 
                Math.sin(theta + Math.PI / 2),
                up[2]
            );
            break;
        case 'A': // Rotate camera counter-clockwise
            theta -= camera_sensitivity;
            up = vec3(
                Math.cos(theta + Math.PI / 2), 
                Math.sin(theta + Math.PI / 2),
                up[2]
            );
            break;
        case 'I': // Isometric view
            cmode = 'I';
            eye = [distancaE, distancaE, distancaE];
            at = [0.0, 0.0, 0.0];
            break;
        case 'W': // Zoom in  
            distancaE -= camera_sensitivity / 2;
            change();
            break;
        case 'S': // Zoom out
            distancaE += camera_sensitivity / 2;
            change();
            break;
        case 'O': // orthographic view
            cmode = 'I';
            pmode = 'ortho';
            eye = [distancaE, distancaE, distancaE];
            at = [0.0, 0.0, 0.0];
            break;
        case 'P': // perspective view
            eye = [0, 0, distancaE];
            at = [0.0, 0.0, 0.0];
            cmode = 'F';
            pmode = 'perspective';
            break;
    }

    render();
}

function change() {
    switch(cmode) {
        case 'T':
            at = [0.0, 0.0, 0.0];
            eye = [0.0, distancaE, 0.01];
            break;
        case 'F':
            at = [0.0, 0.0, 0.0];
            eye = [0, 0, distancaE];
            break;
        case 'L':
            at = [0.0, 0.0, 0.0];
            eye = [distancaE, 0.0, 0.01];
            break;
        case 'R':
            at = [0.0, 0.0, 0.0];
            eye = [0.0, 0.0, -distancaE];
            break;
        case 'I':
            at = [0.0, 0.0, 0.0];
            eye = [distancaE, distancaE, distancaE];
            break;
    }
}